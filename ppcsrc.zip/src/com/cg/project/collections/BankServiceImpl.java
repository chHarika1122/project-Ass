package com.cg.project.collections;

import java.sql.SQLException;

//User defined exception
class MyException extends Exception {
	String s1;

	MyException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

}


//Service layer with implemented method in it
public class BankServiceImpl implements BankService {
	BankDao bd = new BankDaoImpl();             //object creation

	
	 //Validating Name of new account Holder
	public boolean checkName2(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>64 && ch[0]<90) {
					continue;
				} else {
					throw new MyException("     Invalid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}

		}
		return true;

	}

	
	@Override
	public long getBalance(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		long bal = bd.getBalance(accno);
		return bal;
	}

	@Override
	public String getTransaction(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String str = bd.getTransaction(accno);
		return str;
	}

	@Override
	public void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		bd.setBalance(accno, balance, str);
	}

	@Override
	public boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			if (bd.checkAccNo(accno)) {

				return true;
			}

			else
				throw new MyException("    Wrong Account Number");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkPass(String str, long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			if (bd.checkPassword(str, accno)) {

				return true;
			} else
				throw new MyException("    Wrong Password");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkName(String name) {
		// TODO Auto-generated method stub

		String regex = "^[A-Z][a-z]*( [A-Z][a-z]*)*";
		try {
		if(name.matches(regex)) 
		return true;
		else 
			throw new MyException("Invalid Name");}
		catch (MyException E) {
			System.out.println(E);
			return false;
			}
	}

	@Override
	public boolean checkM(String mobileno) {
		// TODO Auto-generated method stub
		int n = mobileno.length();
		char []ch=mobileno.toCharArray();
		
		try {
			if (n == 10 ) {
				for(int i=0;i<n;i++) {
					if(ch[i]>47 && ch[i]<58) {
						continue;
					}
					else
						throw new MyException("    Invalid Number \n    Enter 10 digits");
											
				}
				return true;
				
			} else {
				throw new MyException("    Invalid Number \n    Enter 10 digits");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	@Override
	public boolean checkP(String password) {
		// TODO Auto-generated method stub
		try {
			if (password.length() >= 6) {
				return true;
			} else {
				throw new MyException("    Invalid Password \n    Enter more than six characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}
	}

	@Override
	public String addAccount(String name, String mobile, String password, int i)
			throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		long accNo = Long.parseLong(mobile) - 10000;
		if (bd.checkMobile(mobile)) {
			BankBean bb = new BankBean(name, accNo, mobile, password, 1000, "    Account Created Successfully \n    TransID : "+i+"       Amount Deposited Rs.1000");
			bd.setData(bb);
			return "Account Created Successfully \n    Your Account number is \"" + accNo +"\"\n";
		} else
			return "Account already created ";
	}

	@Override
	public BankBean getInfo(long accno) {
		// TODO Auto-generated method stub
		BankBean b=bd.getInfo(accno);
		return b;
	}
   //End of method implementation 
 	
}
