package com.cg.project.collections;

import java.sql.SQLException;


//Interface with methods to be used along with exception
public interface BankDao {
      
	long getBalance(long accno) throws ClassNotFoundException, SQLException;

	void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException;

	boolean checkMobile(String mobileno) throws ClassNotFoundException, SQLException;


	boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException;

	void setData(BankBean bb) throws ClassNotFoundException, SQLException;

	String getTransaction(long accno);

	boolean checkPassword(String str, long accno) throws ClassNotFoundException, SQLException;

	BankBean getInfo(long accno);
}
