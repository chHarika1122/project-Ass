package com.cg.project.collections;

import java.sql.SQLException;

public class BankBean {

	//Declaration of variables used in project
	private String name;
	private String mobileno;
	private long balance;
	private String password;
	private String transaction;
	private long accno;
	
	//Start of getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobileno;
	}
	public void setMobile(String mobileno) {
		this.mobileno = mobileno;
	}
	public boolean getPassword(String password) {
		if (this.password.equals(password))
			return true;
		else
			return false;

	}

	public String getPassword1() {
		return password;

	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTran() {
		return transaction;
	}
	public void setTran(String transaction) {
		this.transaction = transaction;
	}
	public long getAccNo() {
		return accno;
	}
	public void setAccNo(long accno) {
		this.accno = accno;
	}
	//End of getters and setters
	
	
	//Constructor with variables starts
	public BankBean(String name, long accno, String mobileno, String password, long balance, String transaction) throws SQLException {

		this.name = name;
        this.mobileno = mobileno;
		this.password = password;
		balance = balance;
		transaction = transaction;
		this.accno = accno;

	}
//end of constructor
	
	
	//To convert to string
	@Override
	public String toString() {
		return "CreateAccount [ name=" + name + ", mobileno=" + mobileno + ", balance=" + balance + ", password=" + password
				+ ", transaction=" + transaction + "]";
	}

}
